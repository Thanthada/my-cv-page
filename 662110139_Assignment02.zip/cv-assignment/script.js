const contactButton = document.getElementById('contactBtn');

contactButton.addEventListener('click', function() {
    alert('You can contact me via email: thanthada_s@cmu.ac.th');
});